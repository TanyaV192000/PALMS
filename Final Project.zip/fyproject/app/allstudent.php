<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
 ?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<section class="py-5">
		<div class="container">
			<label><strong>Search student</strong></label>
			<div class="row bg-light align-items-center">
				
				<div class="col-md-2">
					<div class="form-group">

						<label>Select Type</label>
						<select class="form-control" name="srchtype" id="srchtype">
							<option value="id">ID</option>
							
						</select>
					</div>
				</div>
				<div class="col-md-5">
					<div class="input-group pt-2">
						<input placeholder="Enter something..." class="form-control rounded-pill" type="text" name="searchdata" id="searchdata">
						<button class="btn btn-dark datasearch"><i class="fa fa-search text-success"></i></button>
					</div>
				</div>
				
			</div>
			<div class="mt-2 row bg-light py-3 align-items-center">
				<div class="col-md-3">
					<div class="form-group">
						<label>Batch Year</label>
						<select name="yeardt" class="form-control" id="yeardt">
							<option value="2023">2023</option>
							<option value="2022">2022</option>
							<option value="2021">2021</option>
							<option value="2020">2020</option>
							<option value="2019">2019</option>
							<option value="2018">2018</option>
							<option value="2017">2017</option>
						</select>
					</div>
				</div>
				<div class="col-md-4">
					<label>Select Sem</label>
					<div class="input-group">
						
						<select name="semf" class="form-control" id="semf">
							
										<option value="1st Sem">1st Sem</option>
										<option value="2nd Sem">2nd Sem</option>
										<option value="3rd Sem">3rd Sem</option>
										<option value="4th Sem">4th Sem</option>
										<option value="5th Sem">5th Sem</option>
										<option value="6th Sem">6th Sem</option>
										<option value="7th Sem">7th Sem</option>
										<option value="8th Sem">8th Sem</option>
						</select>
						<button class="btn btn-success nextsrch"><i class="fa fa-search"></i></button>
					</div>
				</div>
				
			</div>
			<div class="row hddlist">
				<div class="col-md-12">
					<table class="card rounded-pill bg-success text-white">
						<tr>
							<td>Total Student: </td>
							<td>(<strong><?php $queryt=mysqli_query($db,"SELECT * FROM $utable WHERE type='S'"); echo $rowcountt=mysqli_num_rows($queryt); ?>)
								<i class="fa fa-check-circle text-white ml-2"></i>
								</strong>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
		<div class="container twolist">
			
				  <?php
$start=0;
$limit=10;
if(isset($_GET['id']))
{
$ids=$_GET['id'];
$start=($ids-1)*$limit;
}
else{
$ids=1;
}
$query=mysqli_query($db,"SELECT * FROM $utable WHERE type='S'   order by id desc LIMIT $start, $limit");

$rowcount=mysqli_num_rows($query);
?>
<div class="row">
<?php 
while($getallnewsarr=mysqli_fetch_assoc($query))
{
     ?>
				<div class="col-md-4 mt-3">
					<div class="card mt-5 shadow h-100">
						<div class="card-body">
							<div class="text-center">
							<?php if($getallnewsarr['uimg']==""){ echo '<i class="fa fa-user-circle fa-2x text-danger mr-2"></i>';  }else { echo '<img class="rounded-circle mr-2" width="70" height="70" src="images/'.$getallnewsarr['uimg'].'">'; } ?>
						</div>
							<table class="table table-bordered">
								<tr>
									<td class="text-muted">ID</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['logid']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Password</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['password']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Name</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['name']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Father Name</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['fname']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">College</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['cname']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Email</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['email']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Section</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['mysc']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Sem</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['mysem']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Year</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['year']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Gender</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['gender']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Mobile</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['mnum']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Address</td>
									<td class="font-weight-bold"><?php echo $getallnewsarr['addr']; ?></td>
								</tr>

							</table>
						</div>
					</div>
				</div>
				<?php
}

?>

<?php
$rows=mysqli_num_rows(mysqli_query($db,"SELECT * FROM $utable"));
$total=ceil($rows/$limit);
if($rowcount==0)
{
echo "<div class='alert alert-danger mt-5'><i class='fa fa-warning mr-3'></i>No data found</div>"; 
}
else
{ ?>
</div>
            
            
        
        <?php 
echo "<div class='card-footer mt-5 d-flex justify-content-center'>";  
if($ids>1)
{
echo "<a href='allstudent.php?id=".($ids-1)."' class='btn btn-primary text-white'>PREVIOUS</a>";
}
if($ids!=$total)
{
 echo "<a href='allstudent.php?id=".($ids+1)."' class='btn btn-success text-white ml-4'>NEXT</a>";
}
echo "</div>";
?>

<?php } ?>
			</div>
		
	</section>
			<script type="text/javascript">
				$(document).ready(function(){
					$(".datasearch").click(function(){
					var srchtype=$("#srchtype").val();
					var searchdata=$("#searchdata").val();
					if(searchdata==""){
						alert("Enter something");
						return false;
					}else {
						
						$(".twolist").empty();
						$(".twolist").html('wait <div class="spinner-border text-primary"></div>Searching...');
						$.ajax({
							url:"getsearch.php",
							data:"srchtype="+srchtype+"&searchdata="+searchdata,
							type:"POST",
							success:function(data)
							{
								$(".onlist, .hddlist").hide();
								$(".twolist").html(data);
							}
						})
					}
				});
$(".nextsrch").click(function(){
					var yeardt=$("#yeardt").val();
					var semf=$("#semf").val();
					
						
						$(".twolist").empty();
						$(".twolist").html('wait <div class="spinner-border text-primary"></div>Searching...');
						$.ajax({
							url:"getsearch.php",
							data:"yeardt="+yeardt+"&semf="+semf,
							type:"POST",
							success:function(data)
							{
								$(".onlist, .hddlist").hide();
								$(".twolist").html(data);
							}
						})
					
				}); 

				 });
			</script>		
</body>

<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>