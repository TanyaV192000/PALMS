<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Profile</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);

date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
	$month='0'.$monthe;
}else {
	$month=$monthe;
}
if($dated<10)
{
	$date='0'.$dated;
}else 
{
	$date=$dated;
}
$chkatn=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='".$_SESSION['login']."' AND adncyr='$year' AND adncmnt='$month' AND adncday='$date' AND addyear='".$getarrinfo['year']."' AND sem='".$getarrinfo['mysem']."'");
$chkatnrow=mysqli_num_rows($chkatn);

$getTotalatn=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='".$_SESSION['login']."' AND adncyr='$year' AND adncmnt='$month' AND addyear='".$getarrinfo['year']."' AND sem='".$getarrinfo['mysem']."'");
$getTrow=mysqli_num_rows($getTotalatn);

$getTotalatnSem=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='".$_SESSION['login']."'  AND addyear='".$getarrinfo['year']."' AND sem='".$getarrinfo['mysem']."'");
$getTrowSem=mysqli_num_rows($getTotalatnSem);

 ?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<section class="py-5">
		<div class="container">
			<div class="row bg-light py-3">
				<div class="col-md-12 mb-4">
					<div class="card bg-dark text-white">
						<div class="card-body">
							<h4><i class="fa fa-check-square text-success mr-2"></i>My Attendance</h4>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<h4>Today</h4>
					<hr/>
					
					<nav>
						<?php if($chkatnrow>0){ 
						while($getInfolctu=mysqli_fetch_assoc($chkatn))
						{
						?>
						<span class="badge badge-success mt-2 ml-2 shadow py-2 px-2 rounded-pill">
							<i class="fa fa-check-circle mr-2"></i>
							lucture(<?php echo $getInfolctu['lucture']; ?>)
						</span>
					<?php } }else { echo '<span class="badge badge-danger shadow py-2 px-2 rounded-pill">
							<i class="fa fa-close mr-2"></i>No lucture attend</span>';} ?>
					</nav>
					
				</div>
			</div>
			<div class="row bg-light py-3 mt-3">
				<div class="col-md-12">
					<h4><i class="fa fa-calendar-check-o text-success mr-2"></i>
					This Month <?php if($getTrow>0){
						
						echo '<span class="badge badge-success mt-2 shadow py-2 px-2 rounded-pill">
							<i class="fa fa-check-circle mr-2"></i>('.$getTrow.')
						</span>';

					} else { echo '<span class="badge badge-danger mt-2 shadow py-2 px-2 rounded-pill">
							<i class="fa fa-check-circle mr-2"></i>
							('.$getTrow.')
						</span>';} ?></h4>
						<p class="bg-warning rounded-pill px-2"><strong>Note:- Total attendance by lucture wise</strong></p>
					<?php if($getTrow>0){
						while($getTMatn=mysqli_fetch_assoc($getTotalatn))
						{
						echo '<span class="badge badge-info mt-2 ml-2 shadow py-2 px-2 rounded-pill">
							<i class="fa fa-check-circle mr-2"></i>
							('.$getTMatn['adncday'].'-'.$getTMatn['adncmnt'].'-'.$getTMatn['adncyr'].')</span>';
						}

					} else { echo '<span class="badge badge-danger mt-2 shadow py-2 px-2 rounded-pill">No Data Found</span>';} ?>
				</div>
			</div>
			<div class="row bg-light py-3 shadow mt-3">
				<div class="col-md-12">
					<h4>This Sem <span class="badge badge-dark px-2 py-2"><?php echo $getarrinfo['mysem']; ?> <i class="fa fa-check-circle text-success ml-2"></i></span></h4>
					<?php if($getTrowSem>0){
						echo '<h4><span class="badge badge-primary mt-2 shadow py-2 px-2 rounded-pill">Total: ('.$getTrowSem.') <i class="fa fa-check-circle text-dark ml-2"></i></span></h4>';
					} ?>
				</div>
			</div>
			<div class="row bg-light py-3 shadow mt-3">
				
			</div>
		</div>
	</section>
<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>