<?php 
 require 'db_connection.php';
if(isset($_SESSION['netssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}


if(isset($_POST['stus'])){
    if($_POST['stus']=="A")
    {
        $id=$_POST['id'];
        $lucture=$_POST['luctures'];
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='$id'");
    $getinfos=mysqli_fetch_array($getinfo);
    $sctionss=$getinfos['mysc'];
    $addyear=$getinfos['year'];
    $styear=$getinfos['mysem'];
    
$gwtow1=mysqli_query($db,"SELECT * FROM $uaddate WHERE tid='".$_SESSION['login']."' and section='$sctionss' and addyear='$addyear' and sem='$styear' and adncyr='$year' and adncmnt='$month' and adncday='$date'and lucture='$lucture'");
$whdo=mysqli_num_rows($gwtow1);
if($whdo==0)
{
$gwtow=mysqli_query($db,"INSERT INTO $uaddate SET  tid='".$_SESSION['login']."',section='$sctionss',addyear='$addyear',sem='$styear',adncyr='$year',adncmnt='$month',adncday='$date',lucture='$lucture'");
if($gwtow)
{
    $gwtow3=mysqli_query($db,"SELECT * FROM $uaddate WHERE  tid='".$_SESSION['login']."' and section='$sctionss' and addyear='$addyear' and sem='$styear' and adncyr='$year' and adncmnt='$month' and adncday='$date'and lucture='$lucture'");
    $ggfch=mysqli_fetch_array($gwtow3);
    $ddid=$ggfch['id'];
$insert=mysqli_query($db,"INSERT INTO $uadnctable SET  tid='".$_SESSION['login']."',stid='$id',section='$sctionss',addyear='$addyear',sem='$styear',adncyr='$year',adncmnt='$month',adncday='$date', status='A',thedateid='$ddid',lucture='$lucture'");
        if ($insert) {
            echo 1;
            
        }else{
            echo 0;
        }
}

}else {
    $ggfchww=mysqli_fetch_array($gwtow1);
    $ddid=$ggfchww['id'];
    $setagain=mysqli_query($db,"UPDATE $uadnctable SET status='A' WHERE thedateid='$ddid'");
if ($setagain) {
            echo 1;
            
        }else{
            echo 0;
        }
}



}elseif ($_POST['stus']=="P") {
    $id=$_POST['id'];
        $lucture=$_POST['luctures'];
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='$id'");
    $getinfos=mysqli_fetch_array($getinfo);
    $sctionss=$getinfos['mysc'];
    $addyear=$getinfos['year'];
    $styear=$getinfos['mysem'];
    
$gwtow1=mysqli_query($db,"SELECT * FROM $uaddate WHERE tid='".$_SESSION['login']."' and section='$sctionss' and addyear='$addyear' and sem='$styear' and adncyr='$year' and adncmnt='$month' and adncday='$date'and lucture='$lucture'");
$whdo=mysqli_num_rows($gwtow1);
if($whdo==0)
{
$gwtow=mysqli_query($db,"INSERT INTO $uaddate SET  tid='".$_SESSION['login']."',section='$sctionss',addyear='$addyear',sem='$styear',adncyr='$year',adncmnt='$month',adncday='$date',lucture='$lucture'");
if($gwtow)
{
    $gwtow3=mysqli_query($db,"SELECT * FROM $uaddate WHERE  tid='".$_SESSION['login']."' and section='$sctionss' and addyear='$addyear' and sem='$styear' and adncyr='$year' and adncmnt='$month' and adncday='$date'and lucture='$lucture'");
    $ggfch=mysqli_fetch_array($gwtow3);
    $ddid=$ggfch['id'];
$insert=mysqli_query($db,"INSERT INTO $uadnctable SET  tid='".$_SESSION['login']."',stid='$id',section='$sctionss',addyear='$addyear',sem='$styear',adncyr='$year',adncmnt='$month',adncday='$date', status='P',thedateid='$ddid',lucture='$lucture'");
        if ($insert) {
            echo 1;
            
        }else{
            echo 0;
        }
}

}
 else {
    $ggfchww=mysqli_fetch_array($gwtow1);
    $ddid=$ggfchww['id'];
    $setagain=mysqli_query($db,"UPDATE $uadnctable SET status='P' WHERE thedateid='$ddid'");
if ($setagain) {
            echo 1;
            
        }else{
            echo 0;
        }
}   
}
}
}
}
?>