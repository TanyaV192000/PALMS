<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		header("location:index.php");
 }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Forgot Password</h5>
						<hr>
						<div class="form-group">
							<label>Enter E-mail</label>
							<input id="email" type="text" class="form-control" name="email">
						</div>
						
						<div class="form-group text-center d-flex justify-content-around">
							
							<button class="btn bg1 passbtn">Find <i class="fa fa-search ml-2"></i></button>
							<a href="index.php"><button class="btn btn-dark">Back</button></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".passbtn").click(function(){
var email=$("#email").val();

if(email=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter email id </div>');
return false;
}
if(IsEmail(email)==false){
				    alert("Please enter correct  E-mail");
 		return false;
				  }
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
$(".passbtn").prop("disabled",true);
$.ajax({
	url:"logdata/sender.php",
	data:"email="+email,
	type:"post",
	success:function(data)
	{ alert(data);
		
		if(data==1){
				$("#wrng").html('<div class="badge  w-100 badge-success py-2 px-2 rounded-pill">Successfully sent link <i class="fa fa-check-circle ml-2"></i>, Check your email id link if no link found wait 2 minute</div>');
				$(".passbtn").prop("disabled",false);
			}else {
				$("#wrng").html('<div class="badge mb-2 w-100 badge-danger py-2 px-2 rounded-pill">No email id found<i class="fa fa-close ml-2"></i></div>');
				$(".passbtn").prop("disabled",false);
			}
	}
});

}
});
function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(email)) {
           return false;
        }else{
           return true;
        }
      } 
});
</script>
</body>
<?php } ?>
</html>