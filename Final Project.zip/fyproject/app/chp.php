<?php  include "db_connection.php"; 

if(isset($_POST['password']))
{

$password=mysqli_escape_string($db,$_POST['password']);
$key=$_POST['key'];

$check=mysqli_query($db,"SELECT * FROM $utable WHERE passkey='$key'");
$chrow=mysqli_num_rows($check);
if($chrow>0)
{
	$fccho=mysqli_fetch_assoc($check);
	$geid=$fccho['id'];
	$update=mysqli_query($db,"UPDATE $utable set password='$password' WHERE id='$geid'");
	if($update)
	{
		$updaten=mysqli_query($db,"UPDATE $utable set passkey='' WHERE id='$geid'");
		if($updaten)
		{
			echo 1;
		}else {
			echo 0;
		}
	}
}
}
 ?>
