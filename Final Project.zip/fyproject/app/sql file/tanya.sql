-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2023 at 04:43 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tanya`
--

-- --------------------------------------------------------

--
-- Table structure for table `adancetbl`
--

CREATE TABLE `adancetbl` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `stid` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `lucture` int(11) NOT NULL,
  `adncyr` varchar(100) NOT NULL,
  `adncmnt` varchar(100) NOT NULL,
  `adncday` varchar(100) NOT NULL,
  `status` varchar(500) NOT NULL,
  `addyear` varchar(10) NOT NULL,
  `sem` varchar(10) NOT NULL,
  `thedateid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addatetable`
--

CREATE TABLE `addatetable` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `lucture` int(11) NOT NULL,
  `adncyr` varchar(100) NOT NULL,
  `adncmnt` varchar(100) NOT NULL,
  `adncday` varchar(100) NOT NULL,
  `section` varchar(100) NOT NULL,
  `addyear` varchar(500) NOT NULL,
  `sem` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `atuser`
--

CREATE TABLE `atuser` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL,
  `logid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `uimg` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mysc` varchar(100) NOT NULL,
  `mysem` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mnum` varchar(10) NOT NULL,
  `addr` varchar(700) NOT NULL,
  `passkey` varchar(500) NOT NULL,
  `fistverify` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `atuser`
--

INSERT INTO `atuser` (`id`, `name`, `type`, `logid`, `password`, `uimg`, `fname`, `cname`, `email`, `mysc`, `mysem`, `year`, `gender`, `mnum`, `addr`, `passkey`, `fistverify`) VALUES
(1, 'Tanya', 'A', '123', '123456', '118382719529537.png', '', '', 'lokesh317317@gmail.com', '', '', '', '', '', '', 't', ''),
(19, 'student', 'S', '299815', '360099', '', 'xyz', 'sdsd', 'kapil@gmail.com', 'F', '8th Sem', '2023', 'male', '3454353454', 'ewtertert', '', ''),
(20, 'student sharma', 'T', '889097', '64571', '', '', '', 'xyz@gmail.com', '', '', '', 'female', '45345345', '', '', ''),
(21, 'student sharma', 'T', '914194', '565476', '', '', '', 'xyz@gmail.com', '', '', '', 'female', '45345345', '', '', 'yTHuLrPi61oSj7DBW2vtVa5XKfURxJZedNC3GzhMb8cnYlFOAqw4ms9pgEQIk0'),
(22, 'student sharma', 'T', '298958', '151587', '', '', '', 'xyz@gmail.com', '', '', '', 'female', '45345345', '', '', 'x4d5aMsVnpONSXI1glJcLqDBtCKor8FGuU6yfjTEYeRhzZH207QmvAwk9W3iPb');

-- --------------------------------------------------------

--
-- Table structure for table `markstb`
--

CREATE TABLE `markstb` (
  `id` int(11) NOT NULL,
  `sem` varchar(50) NOT NULL,
  `stsec` varchar(50) NOT NULL,
  `myfile` varchar(300) NOT NULL,
  `adncyr` varchar(10) NOT NULL,
  `adncmnt` varchar(50) NOT NULL,
  `adncday` varchar(10) NOT NULL,
  `tid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `markstb`
--

INSERT INTO `markstb` (`id`, `sem`, `stsec`, `myfile`, `adncyr`, `adncmnt`, `adncday`, `tid`) VALUES
(9, '1st Sem', 'A', '325505527400902.docx', '2023', '05', '16', '1'),
(10, '8th Sem', 'F', '1131470542150626.docx', '2023', '05', '16', '1');

-- --------------------------------------------------------

--
-- Table structure for table `teacheratten`
--

CREATE TABLE `teacheratten` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `thefile` varchar(100) NOT NULL,
  `adncyr` varchar(100) NOT NULL,
  `adncmnt` varchar(100) NOT NULL,
  `adncday` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacheratten`
--

INSERT INTO `teacheratten` (`id`, `tid`, `thefile`, `adncyr`, `adncmnt`, `adncday`) VALUES
(3, 1, '105446223071237.docx', '2023', '05', '09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adancetbl`
--
ALTER TABLE `adancetbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addatetable`
--
ALTER TABLE `addatetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `atuser`
--
ALTER TABLE `atuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `markstb`
--
ALTER TABLE `markstb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacheratten`
--
ALTER TABLE `teacheratten`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adancetbl`
--
ALTER TABLE `adancetbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=308;

--
-- AUTO_INCREMENT for table `addatetable`
--
ALTER TABLE `addatetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `atuser`
--
ALTER TABLE `atuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `markstb`
--
ALTER TABLE `markstb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `teacheratten`
--
ALTER TABLE `teacheratten`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
