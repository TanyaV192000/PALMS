<?php 
 require 'db_connection.php';
if(isset($_SESSION['netssion']))
{
 $sid=$_SESSION['login'];

/* 
 * Custom function to compress image size and 
 * upload to the server using PHP 
 */ 
function compressImage($source, $destination, $quality) { 
    // Get image info 
    $imgInfo = getimagesize($source); 
    $mime = $imgInfo['mime']; 
     
    // Create a new image from file 
    switch($mime){ 
        case 'image/jpeg': 
            $image = imagecreatefromjpeg($source); 
            break; 
        case 'image/png': 
            $image = imagecreatefrompng($source); 
            break; 
        case 'image/gif': 
            $image = imagecreatefromgif($source); 
            break; 
        default: 
            $image = imagecreatefromjpeg($source); 
    } 
     
    // Save image 
    imagejpeg($image, $destination, $quality); 
     
    // Return compressed image 
    return $destination; 
} 
 
 
// File upload path 
$uploadPath = "images/"; 
 
// If file upload form is submitted 
$status = $statusMsg = ''; 
$min_rand=rand(0,1000);
$max_rand=rand(100000000000,10000000000000000);
$name_file=rand($min_rand,$max_rand);//this part is for creating random name for image


$parts = explode('.', $_FILES["image"]["name"]);
$file_extension = end($parts);
$nname=$name_file.".".$file_extension;
    $status = 'error'; 
    if(!empty($_FILES["image"]["name"])) { 
        // File info 
        $utype=mysqli_escape_string($db,$_POST['utype']);
        $name=mysqli_escape_string($db,$_POST['name']);
        $fname=mysqli_escape_string($db,$_POST['fname']);
        $cname=mysqli_escape_string($db,$_POST['cpname']);
        $email=mysqli_escape_string($db,$_POST['email']);
        $mysc=mysqli_escape_string($db,$_POST['mysc']);
        $mysem=mysqli_escape_string($db,$_POST['mysem']);
        $year=mysqli_escape_string($db,$_POST['year']);
        $gender=mysqli_escape_string($db,$_POST['gender']);
        $nber=mysqli_escape_string($db,$_POST['nber']);
        $addr=mysqli_escape_string($db,$_POST['addr']);
     
        $imageUploadPath = $uploadPath . $nname; 
        $fileType = pathinfo($imageUploadPath, PATHINFO_EXTENSION); 
         
        // Allow certain file formats 
        $allowTypes = array('jpg','png','jpeg','gif'); 
        if(in_array($fileType, $allowTypes)){ 
            // Image temp source 
            $imageTemp = $_FILES["image"]["tmp_name"]; 
             
            // Compress size and upload image 
            $compressedImage = compressImage($imageTemp, $imageUploadPath, 50); 
             
            if($compressedImage){ 
                 
                 $pass=rand(00000,999999);
                 $idm=rand(000000,999999);
                 function random_strings($length_of_string) 
{$str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; 
return substr(str_shuffle($str_result), 0, $length_of_string); 
}
 $key=random_strings($idm);
                $insertimg=mysqli_query($db,"INSERT INTO $utable set name='$name', type='$utype', logid='$idm', password='$pass', uimg='$nname', fname='$fname', cname='$cname',email='$email',mysc='$mysc',mysem='$mysem', year='$year', gender='$gender',mnum='$nber',addr='$addr', fistverify='$key'");
                if($insertimg)
                {
                     $statusMsg = '<div class="badge badge-success w-100 px-2 py-2 mb-3">Uploaded <i class="fa fa-check-circle mr-2"></i> </div>';
                }else {
                    $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Image upload failed!</div>';

                }
            }else{ 
                $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Image compress failed!</div>'; 
            } 
        }else{ 
            $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.</div>'; 
        } 
    }else{ 
        $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Please select an image file to upload.</div>'; 
    } 

 
// Display status message 
echo $statusMsg; 
 }
?>