<?php  include "db_connection.php";  ?>
<?php if(isset($_REQUEST['vf'])){  
$getID=mysqli_escape_string($db,$_REQUEST['vf']);
{
	$CHECK=mysqli_query($db,"SELECT * FROM $utable WHERE logid='$getID'");
	$CHEKROWCT=mysqli_num_rows($CHECK);
	if($CHEKROWCT>0)
	{

		$getVfarr=mysqli_fetch_assoc($CHECK);
		if($getVfarr['fistverify']!="")
		{

		

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		header("location:index.php");
 }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="card">
					<div class="card-body">
						<h4>First Verfication</h4>
						<div class="alert alert-danger">
							Please verify your email id, Verification link sent to your email id, Please check your spam menu in  email id
						</div>
						<div class="showmgs"></div>
					</div>
					<div class="card-footer">
						<button class="btn btn-success resend">ReSend</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
	$(document).ready(function(){
		$(".resend").click(function(){
			var id='<?php echo $getID; ?>';
			$(".showmgs").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
 		$(".resend").prop("disabled",true);
			$.ajax({
				url:"resendvf.php",
				data:"id="+id,
				type:"POST",
				success:function(data)
				{
					if(data==1)
					{
						$(".showmgs").html('<div class="badge badge-success py-2 px-2 rounded-pill">Successfully sent link <i class="fa fa-check-circle ml-2"></i>, Check your email id link if no link found wait 2 minute</div>');
				$(".resend").prop("disabled",false);	
					}else {
						$(".showmgs").html('<div class="badge badge-danger py-2 px-2 rounded-pill">Try again <i class="fa fa-close ml-2"></i></div>');
				$(".resend").prop("disabled",false);
					}
				}
			})
		})
	})
</script>
</body>
<?php } ?>
</html>
<?php }else { echo 'Email verificaton successfuly <a href="index.php"><button>Go Back<button></a>';} }else { header("location:index.php");} } } ?>