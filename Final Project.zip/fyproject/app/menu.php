<header class="shadow bg-white">
		<div class="container">
			<div class="float-right dropdown dropleft mt-4">
				<div class="" data-toggle="dropdown">
				<i class="fa fa-cog " ></i>
				</div>
				 <div class="dropdown-menu">
				     <a class="dropdown-item" href="profile.php">Profile</a>
				    <a class="dropdown-item" href="setting.php">Settings</a>
				    <a class="dropdown-item" href="logout.php">Logout</a>
				  </div>
			</div>
			<nav class="navbar navbar-expand-md ">
  <!-- Brand -->
  <a class="navbar-brand text-capitalize text-dark" href="index.php"><?php if($getarrinfo['uimg']==""){ echo '<i class="fa fa-user-circle fa-2x text-danger mr-2"></i>'; echo $getarrinfo['name']; }else { echo '<img class="rounded-circle mr-2" width="47" height="47" src="images/'.$getarrinfo['uimg'].'">';  echo $getarrinfo['name']; } ?></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
   <i class="fa fa-bars text-dark"></i>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse " id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php"><i class="fa fa-home fa-2x"></i></a>
      </li>
    	<?php if($_SESSION['usertyp']=='A') { ?>
    	<li class="nav-item">
        <a class="nav-link" href="allstudent.php"> Students</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="allteacher.php"> Teachers</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="adduser.php"><span class="badge badge-success py-2 text-center rounded-pill"><i class="fa fa-plus text-white"></i></span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="student-attandence.php">Student Attendance</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="marks.php">Upload Marks</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="reports.php">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="teacher-attandence.php">Teacher Attendance</a>
      </li>
    
      <li class="nav-item">
        <a class="nav-link" href="my-attandence.php">My Attendance</a>
      </li>
      <?php }elseif($_SESSION['usertyp']=='T'){ ?>  
        <li class="nav-item">
        <a class="nav-link" href="student-attandence.php">Student Attendance</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="allstudent.php"> Students</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="allteacher.php"> Teachers</a>
      
      <li class="nav-item">
        <a class="nav-link" href="reports.php">Reports</a>
      </li>
       <?php  }else { ?>
      <li class="nav-item">
        <a class="nav-link" href="reports.php">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="teacher-attandence.php">Teacher Attendance</a>
      </li>
    </li>
        <li class="nav-item">
        <a class="nav-link" href="mymarks.php">Marks</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="my-attandence.php">My Attendance</a>
      </li>
      <?php } ?>
    </ul>
  </div>
</nav>
		</div>
	</header>