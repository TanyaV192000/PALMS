<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Settings</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
 ?>
<body class="bg2">
	<?php include"menu.php";  ?>
<section class="py-5">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="card">
					<div class="card-body">
						<h5><i class="fa fa-cog mr-2 text-success"></i>Setting</h5>
						<hr/>
						<div class="media shadow p-2">
							<a class="text-capitalize text-dark" href="index.php"><?php if($getarrinfo['uimg']==""){ echo '<i class="fa fa-user-circle fa-2x text-danger mr-2"></i>';  }else { echo '<img class="rounded-circle mr-2" width="70" height="70" src="images/'.$getarrinfo['uimg'].'">'; } ?></a>
							<div class="media-body">
								<h5><?php echo $getarrinfo['name']; ?></h5>
								<button  data-toggle="modal" data-target="#myModal" class="btn badge badge-success">Edit Image</button>
							</div>
						</div>
						<hr/>
						<ul class="list-group">
							<li class="list-group-item">
								<label>Password</label><br/>
								****** <button data-toggle="modal" data-target="#myModalp" class="btn badge badge-success">Change <i class="fa fa-pencil-square-o></i>"></button>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Profile</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<form id="form"  method="post" enctype="multipart/form-data">
        <div id="preview"><img class="output" id="output"/></div><br>
			      		<input type="file" id="image" name="image" accept="image/*" onchange="loadFile(event)">
			      		<div class="progress my-3">
			              <div id="file-progress-bar" class="progress-bar"></div>
			           </div>
			           <div class="showmsg"></div>
			      		<input type="submit" name="submit" id="but_upload" class="btn btn-success" value="Upload">

						</form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<div class="modal" id="myModalp">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Change Password</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
    <div class="modal-body">
    	<div class="form-group">
    		<label>Send link to change password</label>
    		<input class="form-control" value="123456789" type="password" name="" disabled>
    	</div>
    	<div class="showmgs"></div>
 	</div>

      <!-- Modal footer -->
      <div class="modal-footer">
      	<button class="btn btn-success send">Send</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function () {

$(".send").click(function(){
	$(".showmgs").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
 		$(".send").prop("disabled",true);
	var sent=1;
	$.ajax({
		url:"sendemaillink.php",
		data:"sendt="+sent,
		type:"POST",
		success:function(data)
		{
			
			if(data==1){
				$(".showmgs").html('<div class="badge badge-success py-2 px-2 rounded-pill">Successfully sent link <i class="fa fa-check-circle ml-2"></i>, Check your email id link if no link found wait 2 minute</div>');
				$(".send").prop("disabled",false);
			}else {
				$(".showmgs").html('<div class="badge badge-danger py-2 px-2 rounded-pill">Try again <i class="fa fa-close ml-2"></i></div>');
				$(".send").prop("disabled",false);
			}
		}
	})
})
 }); </script>
<script type="text/javascript">
$(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
 	
 	
 	var files=$("#image").val();
 	
 	
 	if(files=="")
 	{
 		alert("slelct file");
 		return false;
 	}else 
 	{
 		$(".showmsg").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
 		$("#but_upload").prop("disabled",true);
  e.preventDefault();
  $.ajax({
  	 xhr: function() {
                var xhr = new window.XMLHttpRequest();         
                xhr.upload.addEventListener("progress", function(element) {
                    if (element.lengthComputable) {
                        var percentComplete = ((element.loaded / element.total) * 100);
                        $("#file-progress-bar").width(percentComplete + '%');
                        $("#file-progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
         url: "uploadprofile.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend: function(){
                $("#file-progress-bar").width('0%');
            },
   success: function(data)
      {

      	$(".showmsg").html(data);
    	$("#image").val("");
    	$("#showlocal").html("<div class='card bg-success'><div class='card-body text-white'><i class='fa fa-check-circle mr-2'></i>Updated Uploaded</div></div>");
    	$("#but_upload").prop("disabled",false);
    	location.reload();
      },
     error: function(e) 
      {
    $(".showmsg").html(e).fadeIn();
      }          
    });
}
 }));
});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#image").change(function () {
			$(".showmsg").empty("");
			$("#file-progress-bar").width('0%');
		});
	})
</script>
<script type="text/javascript">
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
</script>
</body>

<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>