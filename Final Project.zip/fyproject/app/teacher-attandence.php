<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
	$month='0'.$monthe;
}else {
	$month=$monthe;
}
if($dated<10)
{
	$date='0'.$dated;
}else 
{
	$date=$dated;
}
$current_date = "$date/$month/$year";

 ?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<?php $gettinfo=mysqli_query($db,"SELECT * FROM $utatnce WHERE adncyr='$year' AND adncmnt='$monthe' AND adncday='$dated'");
		$gettrow=mysqli_num_rows($gettinfo);

	 ?>
	<section class="py-5">
		<div class="container">
			
				<div class="row">
				<div id="showlocal" class="col-md-6">
					<?php if($gettrow==0){ echo '<div class="card bg-danger"><div class="card-body text-white"><div class="spinner-grow text-light mr-2"></div>Today Attendance not found 
<strong class="ml-2">'; echo $current_date ; echo '</strong></div></div>';}else { echo '<div class="card bg-success"><div class="card-body text-white"><i class="fa fa-check-circle mr-2"></i>Today Attendance Uploaded 
<strong class="ml-2">'; echo $current_date ; echo '</strong></div></div>'; } ?>
				</div>
			</div>
			<div class="row py-4">
				<?php if(($_SESSION['usertyp']=='T')||($_SESSION['usertyp']=='A')) { ?>
				<div class="col-3"><a href="">
					<div class="badge badge-dark py-2 w-100">Upload File</div>
				</a></div>
			<?php } ?>
				<div class="col-3">
					<a href="viewalltecheratn.php"><div class="badge badge-light py-2 w-100">View All List</div></a>
				</div>
			</div><?php if(($_SESSION['usertyp']=='T')||($_SESSION['usertyp']=='A')) { ?>
			<div class="row mt-4">
				<div class="col-md-6">
					<div class="card">
						<form id="form"  method="post" enctype="multipart/form-data">
							<div class="card-header">
								<i class="fa fa-pencil-square-o mr-2"></i>
								Upload File
							</div>
						<div class="card-body">
							<div class="form-group">
								<label>Select File</label>
								<input type="file" id="image" name="image" onchange="loadFile(event)">
							</div>
							<div class="progress my-3">
			              <div id="file-progress-bar" class="progress-bar"></div>
			           </div>
			           <div class="showmsg"></div>
						</div>
						<div class="card-footer">
							<input type="submit" name="submit" id="but_upload" class="btn btn-success" value="Upload">
						</div>
					</form>
					</div>
				</div>
			</div><?php } ?>
		</div>
	</section>
	<?php if(($_SESSION['usertyp']=='T')||($_SESSION['usertyp']=='A')) { ?>
	<script type="text/javascript">
$(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
 	
 	
 	var files=$("#image").val();
 	
 	
 	if(files=="")
 	{
 		alert("slelct file");
 		return false;
 	}else 
 	{
 		$(".showmsg").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
 		$("#but_upload").prop("disabled",true);
  e.preventDefault();
  $.ajax({
  	 xhr: function() {
                var xhr = new window.XMLHttpRequest();         
                xhr.upload.addEventListener("progress", function(element) {
                    if (element.lengthComputable) {
                        var percentComplete = ((element.loaded / element.total) * 100);
                        $("#file-progress-bar").width(percentComplete + '%');
                        $("#file-progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
         url: "uploadjd.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend: function(){
                $("#file-progress-bar").width('0%');
            },
   success: function(data)
      {

      	$(".showmsg").html(data);
    	$("#image").val("");
    	$("#showlocal").html("<div class='card bg-success'><div class='card-body text-white'><i class='fa fa-check-circle mr-2'></i>Today Attandence Uploaded</div></div>");
    	$("#but_upload").prop("disabled",false);
      },
     error: function(e) 
      {
    $(".showmsg").html(e).fadeIn();
      }          
    });
}
 }));
});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#image").change(function () {
			$(".showmsg").empty("");
			$("#file-progress-bar").width('0%');
		});
	})
</script><?php } ?>
	</body>


<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>