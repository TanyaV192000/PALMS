<?php include "db_connection.php";  if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);

if(isset($_POST['srchtype']))
{
	$id=$_POST['srchtype'];
	$searchdata=$_POST['searchdata'];
	
	$iddata=mysqli_query($db,"SELECT * FROM $utable WHERE logid='$searchdata'");
	$row=mysqli_num_rows($iddata);
	if($row>0)
	{  $getsrch=mysqli_fetch_assoc($iddata);
		$gettotalp=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='".$getsrch['id']."' and status='P'");
		$gettrowp=mysqli_num_rows($gettotalp);
		$gettotala=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='".$getsrch['id']."' and status='A'");
		$gettrowa=mysqli_num_rows($gettotala);
		echo '<div class="row bg-light py-2">
		<div class="col-4"><div class="badge badge-dark w-100 py-2">ID:- '.$searchdata.'<i class="fa fa-check-circle text-success ml-2"></i></div></div><div class="col-4"><div class="badge badge-success w-100 py-2">Total Present: ('.$gettrowp.')</div></div><div class="col-4"><div class="badge badge-danger w-100 py-2">Total Absent: ('.$gettrowa.')</div></div></div>';

		echo '<div class="row">';
		
		?>
		<div class="col-md-4 mt-2">
					<div class="card mt-3 shadow h-100">
						<div class="card-body">
							<div class="text-center">
							<?php if($getsrch['uimg']==""){ echo '<i class="fa fa-user-circle fa-2x text-danger mr-2"></i>';  }else { echo '<img class="rounded-circle mr-2" width="70" height="70" src="images/'.$getsrch['uimg'].'">'; } ?>
						</div>
							<table class="table table-bordered">
								<tr>
									<td class="text-muted">ID</td>
									<td class="font-weight-bold"><?php echo $getsrch['logid']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Password</td>
									<td class="font-weight-bold"><?php echo $getsrch['password']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Name</td>
									<td class="font-weight-bold"><?php echo $getsrch['name']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Father Name</td>
									<td class="font-weight-bold"><?php echo $getsrch['fname']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">College</td>
									<td class="font-weight-bold"><?php echo $getsrch['cname']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Email</td>
									<td class="font-weight-bold"><?php echo $getsrch['email']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Section</td>
									<td class="font-weight-bold"><?php echo $getsrch['mysc']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Sem</td>
									<td class="font-weight-bold"><?php echo $getsrch['mysem']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Year</td>
									<td class="font-weight-bold"><?php echo $getsrch['year']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Gender</td>
									<td class="font-weight-bold"><?php echo $getsrch['gender']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Mobile</td>
									<td class="font-weight-bold"><?php echo $getsrch['mnum']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Address</td>
									<td class="font-weight-bold"><?php echo $getsrch['addr']; ?></td>
								</tr>

							</table>
						</div>
					</div>
				</div>
		<?php
	}else { echo '<div class="badge badge-danger py-2">No data fount</div>';}
	echo '</div>';

}
if(isset($_POST['yeardt']))
{
	$yeardt=$_POST['yeardt'];
	$semf=$_POST['semf'];
	echo '<div class="row bg-light py-2">
		<div class="col-6"><div class="btn badge badge-dark w-100 py-2">'.$yeardt.'<i class="fa fa-check-circle text-success ml-2"></i></div></div>
		<div class="col-6"><div class="btn badge badge-dark w-100 py-2">'.$semf.'<i class="fa fa-check-circle text-success ml-2"></i></div></div></div>';
$iddata=mysqli_query($db,"SELECT * FROM $utable WHERE mysem='$semf'and year='$yeardt'");
	$row=mysqli_num_rows($iddata);
	if($row>0)
	{
		echo '<div class="row bg-light py-2">
		<div class="col-4"><div class="btn badge badge-dark w-100 py-2">Total data found ('.$row.')<i class="fa fa-check-circle text-success ml-2"></i></div></div></div>';
		echo '<div class="row">';
		while($getsrch=mysqli_fetch_assoc($iddata))
		{
			$gete=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$getsrch['id']."'");
			$fnow=mysqli_num_rows($gete);
			if($fnow>0)
			{
				while($getinewarr=mysqli_fetch_assoc($gete))
				{
			
		?>
		<div class="col-md-4 mt-2">
					<div class="card mt-2 shadow h-100">
						<div class="card-body">
							<div class="text-center">
							<?php if($getsrch['uimg']==""){ echo '<i class="fa fa-user-circle fa-2x text-danger mr-2"></i>';  }else { echo '<img class="rounded-circle mr-2" width="70" height="70" src="images/'.$getsrch['uimg'].'">'; } ?>
						</div>
							<table class="table table-bordered">
								<tr>
									<td class="text-muted">ID</td>
									<td class="font-weight-bold"><?php echo $getinewarr['logid']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Password</td>
									<td class="font-weight-bold"><?php echo $getinewarr['password']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Name</td>
									<td class="font-weight-bold"><?php echo $getinewarr['name']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Father Name</td>
									<td class="font-weight-bold"><?php echo $getinewarr['fname']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">College</td>
									<td class="font-weight-bold"><?php echo $getinewarr['cname']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Email</td>
									<td class="font-weight-bold"><?php echo $getinewarr['email']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Section</td>
									<td class="font-weight-bold"><?php echo $getinewarr['mysc']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Sem</td>
									<td class="font-weight-bold"><?php echo $getinewarr['mysem']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Year</td>
									<td class="font-weight-bold"><?php echo $getinewarr['year']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Gender</td>
									<td class="font-weight-bold"><?php echo $getinewarr['gender']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Mobile</td>
									<td class="font-weight-bold"><?php echo $getinewarr['mnum']; ?></td>
								</tr>
								<tr>
									<td class="text-muted">Address</td>
									<td class="font-weight-bold"><?php echo $getinewarr['addr']; ?></td>
								</tr>

							</table>
						</div>
					</div>
				</div>
		<?php
	}} }
	}else { echo '<div class="badge badge-danger py-2">No data fount</div>';}
	echo '</div>';

}
}
}
 ?>