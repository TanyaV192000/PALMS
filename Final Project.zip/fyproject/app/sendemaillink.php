<?php 
 require 'db_connection.php';
if(isset($_SESSION['netssion'])) {
    $uid=$_SESSION['login'];
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

if(isset($_POST['sendt']))
{
    function random_strings($length_of_string) 
{$str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; 
return substr(str_shuffle($str_result), 0, $length_of_string); 
}
$randms=rand(000000,999999);
 $key=random_strings($randms);

 $insertkey=mysqli_query($db,"UPDATE $utable set passkey='$key' WHERE id='$uid'");
 if($insertkey)
 {

  
   $to      = $getarrinfo['email'];
    $subject = 'Change Password Link';
    $message = 'click this link and change your password:- http://www.ciitm.org/app/changepassword.php?key='.$key.'';
    $headers = 'From: webmaster@example.com'       . "\r\n" .
                 'Reply-To: webmaster@example.com' . "\r\n" .
                 'X-Mailer: PHP/' . phpversion();

    $sentiem=mail($to, $subject, $message, $headers);
    if($sentiem)
    {
        echo 1;
    }else {
        echo 0;
    }
}
}

}

}

?>