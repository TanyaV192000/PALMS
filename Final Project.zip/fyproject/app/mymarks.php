<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Marks</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php  if(isset($_SESSION['login'])){
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		$sem=$getarrinfo['mysem'];
		$stsec=$getarrinfo['mysc'];
?>
<body class="bg2">
	<?php include"menu.php"; ?>
<section class="py-5">
	<div class="container threedate">
			<div class="row bg-light py-2">
				<div class="col-md-12">
					<h4>My Marks</h4>
				</div>
			</div>
<div class="row">
<?php
$query=mysqli_query($db,"SELECT * FROM $marks  where sem='$sem' and stsec='$stsec'");

$rowcount=mysqli_num_rows($query);
if($rowcount!=0)
{
?>

<?php 
$getallnewsarr=mysqli_fetch_assoc($query)

     ?>
<div class="col-md-4">
	<div class="card mt-3 shadow">
		<div class="card-body">
			<table class="table table-bordered">
				<tr>
					<td>Sem</td>
					<td><strong><?php echo $getallnewsarr['sem']; ?></strong></td>
				</tr>
				<tr>
					<td>Section</td>
					<td><strong><?php echo $getallnewsarr['stsec']; ?></strong></td>
				</tr>
				<tr>
					<td class="text-muted"><?php echo $getallnewsarr['adncday']; ?>/<?php echo $getallnewsarr['adncmnt']; ?>/<?php echo $getallnewsarr['adncyr']; ?> <i class="fa fa-check-circle text-success ml-2"></i></td>
					<td><a href="uploadmark/<?php echo $getallnewsarr['myfile'];  ?>"><i class="fa fa-file fa-2x text-info"></i></a></td>
					</table>
		</div>
	</div>
</div>
				<?php
}else {echo '<div class="badge badge-danger py-2 px-2">No Marks upload</div>'; }

?>

</div>
</div>
</section>

</body>


<?php
} }else {   
?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>

<?php
}  ?>
</html>