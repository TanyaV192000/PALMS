<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<body>
	<section class="py-5">
		<div class="container">
			<div class="row justify-content-center ">
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<strong><i class="fa fa-key mr-2"></i>Change Password</strong>
						</div>
						<div class="card-body">
					<?php if(isset($_REQUEST['key'])) {
						$key=$_REQUEST['key'];
						if($key=="")
						{
							echo '<div class="alert alert-danger">Something Wrong</div>';
						}else {
							$check=mysqli_query($db,"SELECT * FROM $utable WHERE passkey='$key'");
							$chrow=mysqli_num_rows($check);
							if($chrow>0)
							{
								?>
<form id="form"  method="post" enctype="multipart/form-data">
								<div class="form-group f1">
									<label>Enter new password</label>
									<input type="text" name="password" id="password" class="form-control">
								</div>
								<div class="form-group f2">
									<label>Re-Enter password</label>
									<input type="text" name="rpassword" id="rpassword" class="form-control">
								</div>
								<div class="showmgs"></div>
								<div class="form-group ">
									
									<input type="submit" name="submit" id="but_upload" class="btn btn-success mt-5 bbtn" value="Change">
								
								</div>
								<input type="hidden" name="key" value="<?php echo $key; ?>">
							</form>
								<script type="text/javascript">
									$(document).ready(function(){
										$("#form").on('submit',(function(e) {


										var password = $("#password").val()
					         var password1 = $("#rpassword").val()
					         var pswlen = password.length;
					         if (pswlen < 8) {
					             alert('minmum  8 characters needed');
					             return false;
					         }
					         else {

					            if (password == password1) {
					                 

					                $(".showmgs").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
 		$(".chbtn").prop("disabled",true);
					                  e.preventDefault();
  									$.ajax({
					                 	url:"chp.php",
					                 	data:  new FormData(this),
					                 	type: "POST",
										contentType: false,
										cache: false,
										processData:false,
					                 	success:function(data)
					                 	{
					                 		
					                 		if(data==1){
				$(".showmgs").html('<div class="badge badge-success w-100 py-2 px-2 rounded-pill">Successfully Changed <i class="fa fa-check-circle ml-2"></i></div>');
				$(".send").prop("disabled",false);
				$(".f1,.f2,.bbtn").hide();
				
			}else {
				$(".showmgs").html('<div class="badge badge-danger w-100 mb-3 py-2 px-2 rounded-pill">Try again <i class="fa fa-close ml-2"></i></div>');
				$(".chbtn").prop("disabled",false);
			}
					                 	}
					                 });
					             }
					             else {
					                 alert('please reEnter password');
					             }

					         }
									}));
										});
								</script>
								<?php
							}else {
								header("location:index.php");
							}
						}
					} ?>
						</div>
						<div class="card-footer"><a href="index.php"><button class="btn btn-dark">Back</button></a></div>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
</html>