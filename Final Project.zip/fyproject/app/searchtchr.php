<?php include "db_connection.php"; 

if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		if(isset($_POST['sdate']))
		{
			$pieces = explode("-", $_POST['sdate']);
$y= $pieces[0]; // piece1
$m= $pieces[1]; // piece2
$d= $pieces[2]; // piece2
$gettinfo=mysqli_query($db,"SELECT * FROM $utatnce WHERE adncyr='$y' AND adncmnt='$m' AND adncday='$d'");
		$gettrow=mysqli_num_rows($gettinfo);

if($gettrow>0)
{
	$arrydat=mysqli_fetch_assoc($gettinfo);
	?>
		<div class="card mt-3 shadow">
						<div class="card-body">
							<table class="table table-bordered">
								<tr>
									<td class="text-muted"><?php echo $d; ?>/<?php echo $m; ?>/<?php echo $y; ?> <i class="fa fa-check-circle text-success ml-2"></i></td>
									<td><a href="stfiles/<?php echo $arrydat['thefile'];  ?>"><i class="fa fa-file fa-2x text-info"></i></a></td>
									</table>
						</div>
					</div>
	<?php 
}
}


}
}
 ?>