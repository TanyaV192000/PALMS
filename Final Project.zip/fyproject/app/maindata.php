<?php 
 require 'db_connection.php';
if(isset($_SESSION['netssion']))
{
 $sid=$_SESSION['login'];

        $utype=mysqli_escape_string($db,$_POST['utype']);
        $name=mysqli_escape_string($db,$_POST['name']);
        $fname=mysqli_escape_string($db,$_POST['fname']);
        $cname=mysqli_escape_string($db,$_POST['cpname']);
        $email=mysqli_escape_string($db,$_POST['email']);
        $mysc=mysqli_escape_string($db,$_POST['mysc']);
        $mysem=mysqli_escape_string($db,$_POST['mysem']);
        $year=mysqli_escape_string($db,$_POST['year']);
        $gender=mysqli_escape_string($db,$_POST['gender']);
        $nber=mysqli_escape_string($db,$_POST['nber']);
        $addr=mysqli_escape_string($db,$_POST['addr']);
     
        
                 $pass=rand(00000,999999);
                 $idm=rand(000000,999999);
                 function random_strings($length_of_string) 
{$str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; 
return substr(str_shuffle($str_result), 0, $length_of_string); 
}
 $key=random_strings($idm);
                $insertimg=mysqli_query($db,"INSERT INTO $utable set name='$name', type='$utype', logid='$idm', password='$pass', fname='$fname', cname='$cname',email='$email',mysc='$mysc',mysem='$mysem', year='$year', gender='$gender',mnum='$nber',addr='$addr', fistverify='$key'");
                if($insertimg)
                {
                     echo $statusMsg = '<div class="badge badge-success w-100 px-2 py-2 mb-3">Uploaded <i class="fa fa-check-circle mr-2"></i> </div>';
                }else {
                   echo $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Image upload failed!</div>';

                }
      }      
?>