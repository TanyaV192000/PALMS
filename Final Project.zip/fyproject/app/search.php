<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
 ?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<section class="py-5">
		<div class="container">
			<div class="row bg-light align-items-center">
				<div class="col-md-2">
					<div class="form-group">
						<label>Select Type</label>
						<select class="form-control" name="srchtype" id="srchtype">
							<option value="id">ID</option>
							<option value="name">Name</option>
						</select>
					</div>
				</div>
				<div class="col-md-5">
					<div class="input-group pt-2">
						<input placeholder="Enter something..." class="form-control rounded-pill" type="text" name="searchdata" id="searchdata">
						<button class="btn btn-light"><i class="fa fa-search text-success"></i></button>
					</div>
				</div>
			</div>
		</div>
	</section>

	</body>

<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>