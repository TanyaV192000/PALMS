<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
 ?>
<body class="bg2">
<?php include"menu.php"; ?>
<section class="py-5">
	<div class="container">
		<div class="row bg3 py-3">
			<div class="col-md-12 text-white">
				<h4><i class="fa fa-check-circle mr-2"></i>Add Attendance</h4>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row bg-white py-3 align-items-center">
			<div class="col-md-2">
				<div class="card">
					<div class="card-body">
						<div class="form-group">
									<label>Select Year</label>
									<select name="year" id="year" class="form-control">
										<option value="">Select Year</option>
										<option value="2023">2023</option>
										<option value="2022">2022</option>
										<option value="2021">2021</option>
										<option value="2020">2020</option>
										<option value="2019">2019</option>
										<option value="2018">2018</option>
										<option value="2017">2017</option>
										<option value="2016">2016</option>
										<option value="2015">2015</option>
									</select>
								</div>
					</div>
				</div>
			</div>
			<div class="col-md-2">
				<div class="card">
					<div class="card-body">
						<div class="form-group">
							<label>Lucture Number</label>
							<select class="form-control " name="lucture" id="lucture">
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
							</select>
						</div>

					</div>
				</div>
			</div>
			<div class="col-md-2">
				<div class="card">
					<div class="card-body">
						<div class="form-group">
									<label>Select Section </label>
									<select name="mysc" id="mysc" class="form-control">
										<option value="">Select Section</option>
										<option value="A">A</option>
										<option value="B">B</option>
										<option value="C">C</option>
										<option value="D">D</option>
										<option value="E">E</option>
										<option value="F">F</option>
									</select>
								</div>

					</div>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="card">
					<div class="card-body">
						<div class="form-group">
									<label>Select Sem</label>
									<select name="mysem" id="mysem" class="form-control">
										<option value="">Select Semester</option>
										<option value="1st Sem">1st Sem</option>
										<option value="2nd Sem">2nd Sem</option>
										<option value="3rd Sem">3rd Sem</option>
										<option value="4th Sem">4th Sem</option>
										<option value="5th Sem">5th Sem</option>
										<option value="6th Sem">6th Sem</option>
										<option value="7th Sem">7th Sem</option>
										<option value="8th Sem">8th Sem</option>
									</select>
								</div>
					</div>
				</div>
			</div>
			<div class="col-md-2">
				<div class="card h-100">
					<div class="card-body ">
						<button class="btn btn-light searchst"><i class="fa fa-search fa-2x text-success"></i></button>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body " id="showdata"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
	$(document).ready(function(){
		$(".searchst").click(function(){
			var year=$("#year").val();
			var lucture=$("#lucture").val();
			var mysc=$("#mysc").val();
			var mysem=$("#mysem").val();
			
			if(year==""){
				alert("Please select year");
				return false;
			}
			if(lucture==""){
				alert("Please select lucture");
				return false;
			}
			if(mysc==""){
				alert("Please select section");
				return false;
			}
			if(mysem==""){
				alert("Please select sem");
				return false;
			}else {
				$("#showdata").html('<div class="spinner-border text-primary"></div>Please wait..');
			$.ajax({
				url:"searchforatten.php",
				data:"year="+year+"&lucture="+lucture+"&mysc="+mysc+"&mysem="+mysem,
				type:"POST",
				success:function(data)
				{

					if(data==0){
						$("#showdata").empty();
						$("#showdata").html('<div class="badge badge-danger py-2 w-100">No data found</div>');
						return false;
					}else {
						
						$("#showdata").empty();
						$("#showdata").html(data);
					}
				}

			});
		}
		})
	})
</script>
</body>


<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>