<?php 
 require 'db_connection.php';
if(isset($_SESSION['netssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}

$checkrow=mysqli_query($db,"SELECT * FROM teacheratten WHERE adncyr='$year' and adncmnt='$month' and adncday='$date'");
$chkmanrow=mysqli_num_rows($checkrow);
if($chkmanrow==0)
{
$uploadPath = "stfiles/"; 
 if(isset($_FILES['image'])){
    
 
 
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      
      $parts = explode('.', $_FILES["image"]["name"]);
$file_extension = end($parts);
      $extensions= array("jpeg","jpg","png","pdf","xls","xlsx","docm","docx","dot","dotx","zip","pptx","pptm","ppt");
      
      if(in_array($file_extension,$extensions)=== false){
         $errors[]="extension not allowed";
      }
      
      
    $min_rand=rand(0,1000);
 $max_rand=rand(100000000000,10000000000000000);
 $name_file=rand($min_rand,$max_rand);

$nname=$name_file.".".$file_extension;
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,$uploadPath.$nname);
         $insertdata=mysqli_query($db,"INSERT INTO $utatnce set  tid='".$_SESSION['login']."',thefile='$nname',adncyr='$year',adncmnt='$month',adncday='$date'");
         if($insertdata)
         {
           echo '<div class="badge badge-success px-2 py-2 rounded-pill text-center mb-2">Successfully uploaded <i class="fa fa-check-circle text-white ml-2"></i></div>'; 
         }
         
      }else{
         print_r($errors);
      }
   }
}
}
}
?>