<?php
include "db_connection.php"; 
 if(isset($_SESSION['netssion'])) {
session_destroy();
header("location:index.php");

 }

?>