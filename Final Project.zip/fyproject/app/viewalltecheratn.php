<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
	$month='0'.$monthe;
}else {
	$month=$monthe;
}
if($dated<10)
{
	$date='0'.$dated;
}else 
{
	$date=$dated;
}
$current_date = "$date/$month/$year";

 ?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<?php $gettinfo=mysqli_query($db,"SELECT * FROM $utatnce WHERE adncyr='$year' AND adncmnt='$monthe' AND adncday='$dated'");
		$gettrow=mysqli_num_rows($gettinfo);

	 ?>
	<section class="py-5">
		<div class="container">
			<div class="row bg-light py-2 align-items-center">
				<div class="col-md-12">
					<h4>Search Attendance</h4>
				</div>
				<div class="col-4">
					<div class="form-group">
						<label>Select date</label>
						<input type="date" name="sdate" id="sdate" class="form-control">
					</div>
				</div>
				<div class="col-8">
					<button class="btn btn-success mt-2 srch"><i class="fa fa-search"></i></button>
				</div>
			</div>
				<div class="row mt-3 onedate">
				<div id="showlocal" class="col-md-6">
					<?php if($gettrow==0){ echo '<div class="card bg-danger"><div class="card-body text-white"><div class="spinner-grow text-light mr-2"></div>Today Attendance not found 
<strong class="ml-2">'; echo $current_date ; echo '</strong></div></div>';}else { echo '<div class="card bg-success"><div class="card-body text-white"><i class="fa fa-check-circle mr-2"></i>Today Attendance Uploaded 
<strong class="ml-2">'; echo $current_date ; echo '</strong></div></div>'; } ?>
				</div>
			</div>
			<div class="row py-4 twodate">
				<?php if(($_SESSION['usertyp']=='T')||($_SESSION['usertyp']=='A')) { ?>
				<div class="col-3"><a href="teacher-attandence.php">
					<div class="badge badge-light py-2 w-100">Upload File</div>
				</a></div>
			<?php } ?>
				<div class="col-3">
					<a href="viewalltecheratn.php"><div class="badge badge-dark py-2 w-100">View All List</div></a>
				</div>
			</div>
</div>
</section>
<section>
	<div class="container threedate">
			
				  <?php
$start=0;
$limit=10;
if(isset($_GET['id']))
{
$ids=$_GET['id'];
$start=($ids-1)*$limit;
}
else{
$ids=1;
}
$query=mysqli_query($db,"SELECT * FROM $utatnce  order by id desc LIMIT $start, $limit");

$rowcount=mysqli_num_rows($query);
?>
<div class="row">
<?php 
while($getallnewsarr=mysqli_fetch_assoc($query))
{
     ?>
				<div class="col-md-4">
					<div class="card mt-3 shadow">
						<div class="card-body">
							<table class="table table-bordered">
								<tr>
									<td class="text-muted"><?php echo $getallnewsarr['adncday']; ?>/<?php echo $getallnewsarr['adncmnt']; ?>/<?php echo $getallnewsarr['adncyr']; ?> <i class="fa fa-check-circle text-success ml-2"></i></td>
									<td><a href="stfiles/<?php echo $getallnewsarr['thefile'];  ?>"><i class="fa fa-file fa-2x text-info"></i></a></td>
									</table>
						</div>
					</div>
				</div>
				<?php
}

?>

<?php
$rows=mysqli_num_rows(mysqli_query($db,"SELECT * FROM $utatnce"));
$total=ceil($rows/$limit);
if($rowcount==0)
{
echo "<div class='alert alert-danger mt-5'><i class='fa fa-warning mr-3'></i>No data found</div>"; 
}
else
{ ?>
</div>
            
            
        
        <?php 
echo "<div class='card-footer d-flex justify-content-center mt-5'>";  
if($ids>1)
{
echo "<a href='viewalltecheratn.php?id=".($ids-1)."' class='btn btn-primary text-white'>PREVIOUS</a>";
}
if($ids!=$total)
{
 echo "<a href='viewalltecheratn.php?id=".($ids+1)."' class='btn btn-success text-white ml-4'>NEXT</a>";
}
echo "</div>";
?>

<?php } ?>
			
		</div>
	
</section>
<script type="text/javascript">
	$(document).ready(function(){
		$(".srch").click(function(){
			var sdate=$("#sdate").val();
			if(sdate=="")
			{
				alert("Please select date");
				return false;
			}else 
			{
				$(".onedate, .twodate").hide();
				$(".threedate").empty();
				$(".threedate").html('<div class="spinner-border text-primary"></div>Please wait..');
				$.ajax({
				url:"searchtchr.php",
				data:"sdate="+sdate,
				type:"POST",
				success:function(data)
				{

					if(data==1){
						$(".threedate").empty();
						$(".threedate").html('<div class="badge badge-danger py-2 w-100">No data found</div>');
					}else {
						
						$(".threedate").empty();
						$(".threedate").html(data);
					}
				}

			});
			}
		})
	})
</script>
			</body>


<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>