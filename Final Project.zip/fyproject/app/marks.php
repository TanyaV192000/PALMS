<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Marks</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php  if(isset($_SESSION['login'])){
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<section class="py-5">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="card">
						<form id="form"  method="post" enctype="multipart/form-data">
						<div class="card-body">
							<h4><i class="fa fa-pencil-square-o mr-2 text-success"></i>Add Marks</h4>
							
								<div class="form-group">
									<label>Select Sem</label>
									<select name="mysem" id="mysem" class="form-control">
										<option value="">Select Semester</option>
										<option value="1st Sem">1st Sem</option>
										<option value="2nd Sem">2nd Sem</option>
										<option value="3rd Sem">3rd Sem</option>
										<option value="4th Sem">4th Sem</option>
										<option value="5th Sem">5th Sem</option>
										<option value="6th Sem">6th Sem</option>
										<option value="7th Sem">7th Sem</option>
										<option value="8th Sem">8th Sem</option>
									</select>
								</div>
								<div class="form-group">
									<label>Select Section </label>
									<select name="mysc" id="mysc" class="form-control">
										<option value="">Select Section</option>
										<option value="A">A</option>
										<option value="B">B</option>
										<option value="C">C</option>
										<option value="D">D</option>
										<option value="E">E</option>
										<option value="F">F</option>
									</select>
								</div>
								<div class="form-group mt-5">
								<label>Select File</label>
								<input type="file" id="image" name="image" onchange="loadFile(event)">
							</div>
							<div class="progress my-3">
			              <div id="file-progress-bar" class="progress-bar"></div>
			           </div>
			           <div class="showmsg"></div>

							
						</div>
						<div class="card-footer">
							<input type="submit" name="submit" id="but_upload" class="btn btn-success" value="Upload">
						</div>
					</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section>
	<div class="container threedate">
			<div class="row bg-light py-2">
				<div class="col-md-12">
					<h4>All List</h4>
				</div>
			</div>
				  <?php
$start=0;
$limit=10;
if(isset($_GET['id']))
{
$ids=$_GET['id'];
$start=($ids-1)*$limit;
}
else{
$ids=1;
}
$query=mysqli_query($db,"SELECT * FROM $marks  order by id desc LIMIT $start, $limit");

$rowcount=mysqli_num_rows($query);
?>
<div class="row">
<?php 
while($getallnewsarr=mysqli_fetch_assoc($query))
{
     ?>
<div class="col-md-4">
	<div class="card mt-3 shadow">
		<div class="card-body">
			<table class="table table-bordered">
				<tr>
					<td>Sem</td>
					<td><strong><?php echo $getallnewsarr['sem']; ?></strong></td>
				</tr>
				<tr>
					<td>Section</td>
					<td><strong><?php echo $getallnewsarr['stsec']; ?></strong></td>
				</tr>
				<tr>
					<td class="text-muted"><?php echo $getallnewsarr['adncday']; ?>/<?php echo $getallnewsarr['adncmnt']; ?>/<?php echo $getallnewsarr['adncyr']; ?> <i class="fa fa-check-circle text-success ml-2"></i></td>
					<td><a href="uploadmark/<?php echo $getallnewsarr['myfile'];  ?>"><i class="fa fa-file fa-2x text-info"></i></a></td>
					</table>
		</div>
	</div>
</div>
				<?php
}

?>

<?php
$rows=mysqli_num_rows(mysqli_query($db,"SELECT * FROM $marks"));
$total=ceil($rows/$limit);
if($rowcount==0)
{
echo "<div class='alert alert-danger mt-5'><i class='fa fa-warning mr-3'></i>No data found</div>"; 
}
else
{ ?>
</div>
            
            
        
        <?php 
echo "<div class='card-footer d-flex justify-content-center mt-5'>";  
if($ids>1)
{
echo "<a href='marks.php?id=".($ids-1)."' class='btn btn-primary text-white'>PREVIOUS</a>";
}
if($ids!=$total)
{
 echo "<a href='marks.php?id=".($ids+1)."' class='btn btn-success text-white ml-4'>NEXT</a>";
}
echo "</div>";
?>

<?php } ?>
			
		</div>
	
</section>
<script type="text/javascript">
$(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
 	
 	
 	var files=$("#image").val();
 	
 	
 	if(files=="")
 	{
 		alert("slelct file");
 		return false;
 	}else 
 	{
 		$(".showmsg").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
 		$("#but_upload").prop("disabled",true);
  e.preventDefault();
  $.ajax({
  	 xhr: function() {
                var xhr = new window.XMLHttpRequest();         
                xhr.upload.addEventListener("progress", function(element) {
                    if (element.lengthComputable) {
                        var percentComplete = ((element.loaded / element.total) * 100);
                        $("#file-progress-bar").width(percentComplete + '%');
                        $("#file-progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
         url: "uploadmarks.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend: function(){
                $("#file-progress-bar").width('0%');
            },
   success: function(data)
      {

      	$(".showmsg").html(data);
    	$("#image").val("");
    	$("#showlocal").html("<div class='card bg-success'><div class='card-body text-white'><i class='fa fa-check-circle mr-2'></i>Today Attandence Uploaded</div></div>");
    	$("#but_upload").prop("disabled",false);
      },
     error: function(e) 
      {
    $(".showmsg").html(e).fadeIn();
      }          
    });
}
 }));
});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#image").change(function () {
			$(".showmsg").empty("");
			$("#file-progress-bar").width('0%');
		});
	})
</script>
</body>


<?php
} }else {   
?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>

<?php
}  ?>
</html>