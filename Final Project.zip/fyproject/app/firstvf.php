<?php  include "db_connection.php";  ?>
<?php if(isset($_REQUEST['key'])){
	$eky=$_REQUEST['key'];
	if($eky!="")
	{
		$chekkey=mysqli_query($db,"SELECT * FROM $utable WHERE fistverify='$eky'");
		$GETROW=mysqli_num_rows($chekkey);
		if($GETROW>0)
		{
			$getsql=mysqli_fetch_assoc($chekkey);
			if($getsql['fistverify']!="")
			{

	?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<body>
	<section class="py-5">
		<div class="container">
			<div class="row justify-content-center ">
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<strong><i class="fa fa-envelope-o mr-2"></i>Verification email</strong>
						</div>
						<div class="card-body">
							<?php $upd=mysqli_query($db,"UPDATE $utable set fistverify='' WHERE id='".$getsql['id']."'"); 
									if($upd)
									{
										echo '<div class="badge badge-success py-2 px-2 w-100">Your Email id successfuly verified <i class="fa fa-check-circle ml-2"></i></div><a href="index.php"><br/><button>Go Back<button></a>';
									}
									else {
										echo '<div class="badge badge-danger py-2 px-2 w-100">Please try again <i class="fa fa-close ml-2"></i></div>';
									}
							 ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
</html>
<?php }else { echo 'Email verificaton successfuly <a href="index.php"><button>Go Back<button></a>';} } } } ?>