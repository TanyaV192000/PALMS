<?php
session_start();

// change the information according to your database
$db = mysqli_connect("localhost","root","","ntanya");
// CHECK DATABASE CONNECTION
if(mysqli_connect_errno()){
    echo "Connection Failed".mysqli_connect_error();
    exit;
}
$utable='atuser';
$uadnctable='adancetbl';
$uaddate='addatetable';
$utatnce='teacheratten';
$marks='markstb';
?>