<?php 
include"../db_connection.php";
if(isset($_POST['mid']))
{
	$a=$_POST['mid'];
	 $b=$_POST['password'];

$check=mysqli_query($db,"SELECT * FROM atuser WHERE logid='$a' and password='$b'");
$checkrow=mysqli_num_rows($check);
if($checkrow>0)
{
	$array=mysqli_fetch_array($check);

	$_SESSION['myid']=$array['id'];
	$_SESSION['myname']=$array['name'];
	echo 1;

}else 
{
	echo 0;
}

}

 ?>