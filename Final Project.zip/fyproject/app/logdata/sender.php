<?php 
 require '../db_connection.php';

if(isset($_POST['email']))
{
   $email=mysqli_escape_string($db,$_POST['email']);
    $getem=mysqli_query($db,"SELECT * FROM $utable WHERE email='$email'");
    $ageirow=mysqli_num_rows($getem);
    $fchdasta=mysqli_fetch_assoc($getem);
    if($ageirow>0)
    {
    function random_strings($length_of_string) 
{$str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; 
return substr(str_shuffle($str_result), 0, $length_of_string); 
}
 $key=random_strings($fchdasta['id']);

 $insertkey=mysqli_query($db,"UPDATE $utable set passkey='$key' WHERE email='$email'");
 if($insertkey)
 {

  
   $to      = $email;
    $subject = 'Change Password Link';
    $message = '<a href="http://www.ciitm.org/app/changepassword.php?key='.$key.'">Change Password click here</a>';
    $headers = 'From: webmaster@example.com'       . "\r\n" .
                 'Reply-To: webmaster@example.com' . "\r\n" .
                 'X-Mailer: PHP/' . phpversion();

    $sentiem=mail($to, $subject, $message, $headers);
    if($sentiem)
    {
        echo 1;
    }else {
        echo 0;
    }
}else { echo 0 ; }
}else { echo 0 ; }
}

?>