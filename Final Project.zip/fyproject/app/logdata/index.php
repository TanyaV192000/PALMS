<?php  include "../db_connection.php";

if(isset($_POST['mid']))
{
$mid=mysqli_escape_string($db,$_POST['mid']);
$pass=mysqli_escape_string($db,$_POST['password']);
if($mid=="")
{
	echo 1;
}
elseif ($pass=="") {
	echo 2;
}else {
	
	$checkinfo=mysqli_query($db,"SELECT * FROM $utable WHERE logid='$mid' AND password='$pass'");
	 $getrow=mysqli_num_rows($checkinfo);
	if($getrow>0)
	{
		$getarr=mysqli_fetch_assoc($checkinfo);
		if($getarr['fistverify']!="")
		{
		$to      = $getarr['email'];
    $subject = 'Email verificaton link';
    $message = 'click this link and verify email id http://www.ciitm.org/app/firstvf.php?key='.$getarr['fistverify'].'';
    $headers = 'From: webmaster@example.com'       . "\r\n" .
                 'Reply-To: webmaster@example.com' . "\r\n" .
                 'X-Mailer: PHP/' . phpversion();

    $sentiem=mail($to, $subject, $message, $headers);
    if($sentiem)
    {
        echo 4;
    }else {
        echo 0;
    }
		}else {


		$_SESSION['login']=$getarr['id'];
	 $_SESSION['loginUser']=$getarr['name'];
		$_SESSION['netssion']="14224";
		$_SESSION['stidmain']=$getarr['logid'];
		$_SESSION['usertyp']=$getarr['type'];
		echo 3;
	}
	}else {
		echo 0;
	}
}

}
 ?>
	
