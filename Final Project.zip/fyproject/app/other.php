<?php  include "db_connection.php";  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script> 

</head>
<?php if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
 ?>
<body class="bg2">
	<?php include"menu.php"; ?>
	<section>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6">
					<div class="card mt-5">
						<div class="card-body">
							<h4><i class="fa fa-pencil-square-o mr-2 text-success"></i>Add Teacher Info</h4>
							<hr/>
							<form id="form"  method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label>Select user type</label>
								<select class="form-control" name="utype" id="utype">
									<option value="">Select Type</option>
									<option value="S">Student</option>
									<option value="T">Teacher</option>
									
								</select>
							</div>
							<div class="form-group">
<label>Enter teacher name</label>
<input type="text" name="name" id="name" class="form-control">
</div>
<div class="form-group">
									<label>Select Gender</label>
									<select name="gender" id="gender" class="form-control">
										<option value="">Select Gender</option>
										<option value="male">Male</option>
										<option value="female">Female</option>
										<option value="Other">Other</option>

									</select>
								</div>
								<div class="form-group">
									<label>Enter Phone number</label>
									<input type="number" name="nber" id="nber" class="form-control">
								</div>
								<div class="form-group">
									<label>Enter E-mail</label>
									<input type="text" name="email" id="email" class="form-control">
								</div>
<!--<div id="preview"><img class="output" id="output"/></div><br>
<input type="file" id="image" name="image" accept="image/*" onchange="loadFile(event)">-->
<div class="progress my-3">
<div id="file-progress-bar" class="progress-bar"></div>
</div>
<div class="showmsg"></div>
<input type="submit" name="submit" id="but_upload" class="btn btn-success" value="Upload">

						</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<script type="text/javascript">
$(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
 	var utype=$("#utype").val();
 	var name=$("#name").val();
 	var gender=$("#gender").val();
 	var nber=$("#nber").val();
 	var email=$("#email").val();
 	//var files=$("#image").val();
 		if(utype=="")
 	{
 		alert("Please select user type ");
 		return false;
 	}
 	if(name=="")
 	{
 		alert("Please enter name");
 		return false;
 	}
 		if(gender=="")
 	{
 		alert("Please Select gender");
 		return false;
 	}
 	if(nber=="")
 	{
 		alert("Please enter mobile number");
 		return false;
 	}
 	if(email=="")
 	{
 		alert("Please enter  E-mail");
 		return false;
 	}
 	if(IsEmail(email)==false){
				    alert("Please enter correct  E-mail");
 		return false;
				  }
//  	if(files=="")
//  	{
//  		alert("slelct image");
//  		return false;
//  	}
 	else 
 	{
 		$(".showmsg").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
  e.preventDefault();
  $.ajax({
  	 xhr: function() {
                var xhr = new window.XMLHttpRequest();         
                xhr.upload.addEventListener("progress", function(element) {
                    if (element.lengthComputable) {
                        var percentComplete = ((element.loaded / element.total) * 100);
                        $("#file-progress-bar").width(percentComplete + '%');
                        $("#file-progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
         url: "uploadimgt.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend: function(){
                $("#file-progress-bar").width('0%');
            },
   success: function(data)
      {


      	$(".showmsg").html(data);
    	//$("#image").val("");
    	//$('#output').attr('src', '');
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
}
 }));
 function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(email)) {
           return false;
        }else{
           return true;
        }
      } 
});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#image").change(function () {
			$(".showmsg").empty("");
			$("#file-progress-bar").width('0%');
		});
		
	})
</script>
<script type="text/javascript">
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
</script>
<script type="text/javascript">
		$(document).ready(function(){ 

			$('#utype').on('change', function() {
    var mval=$("#utype").val();
    if(mval=='S')
    {
    window.location.href="adduser.php";
    	
    }


			});
		})
	</script>
</body>

<?php }else { echo "No data found"; } }else { ?>
<body class="bg1">
<section class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-5">
				<div class="card">
					<div class="card-body">
						<div id="wrng"></div>
						<h5><i class="fa fa-user-circle mr-2"></i>Login</h5>
						<hr>
						<div class="form-group">
							<label>Enter ID</label>
							<input id="mid" type="text" class="form-control" name="mid">
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input id="password" type="password" class="form-control" name="password">
						</div>
						<div class="form-group">
							<button class="btn bg1 gologin">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function(){
$(".gologin").click(function(){
var mid=$("#mid").val();
var password=$("#password").val();
if(mid=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter id </div>');
return false;
}
if(password=="")
{
$("#wrng").empty();
$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i>Please enter password </div>');
return false;
}
else 
{

	$("#wrng").empty();
$("#wrng").html('<div class="badge badge-warning w-100 px-2 py-3"><i class="fa fa-warning mr-4"></i> Authentication... wait <div class="spinner-border text-primary"></div></div>');
$.ajax({
	url:"logdata/index.php",
	data:"mid="+mid+"&password="+password,
	type:"post",
	success:function(data)
	{
		alert(data);
		if(data==1){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter id<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		if(data==2){

		$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Please enter password<i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		return false;
		}
		

		if(data==3)
		{	

			$("#wrng").empty();
			$("#wrng").html('<div class="text-success w-100 px-2 py-3"><div class="spinner-border text-primary"></div>Successfully logedIn..  Wait Redirecting<i class="fa fa-check-circle ml-2" aria-hidden="true"></i></div>');
			setTimeout(function() {
		      window.location.href="index.php";
		    }, 2000);

		}else 
		{
			$("#wrng").empty();
		$("#wrng").html('<div class="badge badge-danger w-100 px-2 py-3">Invalid data <i class="fa fa-close-circle ml-2" aria-hidden="true"></i></div>');
		}
		
	}
});

}
});

});
</script>
</body>
<?php } ?>
</html>