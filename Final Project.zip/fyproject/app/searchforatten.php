<?php include "db_connection.php"; 
if(isset($_SESSION['netssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		if(isset($_POST['year']))
		{

date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
	$month='0'.$monthe;
}else {
	$month=$monthe;
}
if($dated<10)
{
	$date='0'.$dated;
}else 
{
	$date=$dated;
}
$yearr=$_POST['year'];
$lucture=$_POST['lucture'];
$mysc=$_POST['mysc'];
$mysem=$_POST['mysem'];
$current_date = "$date/$month/$year";
 $gettinfo=mysqli_query($db,"SELECT * FROM $uaddate WHERE lucture='$lucture' and adncyr='$year' AND adncmnt='$month' AND adncday='$date' and section='$mysc' and addyear='$yearr' and sem='$mysem'");
		$gettrow=mysqli_num_rows($gettinfo);
		$gettarr=mysqli_fetch_assoc($gettinfo);
	 if($gettrow==0){ echo '<div class="card bg-danger"><div class="card-body text-white"><div class="spinner-grow text-light mr-2"></div>Today Attandence not found 
<strong class="ml-2">'; echo $current_date ; echo '</strong></div></div>';}else { echo '<div class="card bg-success"><div class="card-body text-white"><i class="fa fa-check-circle mr-2"></i>Today Attandence Uploaded 
<strong class="ml-2">'; echo $current_date ; echo '</strong></div></div>'; }
if($gettrow!=0){
$gettolp=mysqli_query($db,"SELECT * FROM $uadnctable WHERE thedateid='".$gettarr['id']."' and status='P'");
$getrowPrstnt=mysqli_num_rows($gettolp);
$gettolaa=mysqli_query($db,"SELECT * FROM $uadnctable WHERE thedateid='".$gettarr['id']."' and status='A'");
$getrowPrstnta=mysqli_num_rows($gettolaa);?>
<div class="card"><div class="card-body d-flex"><table class="px-3 py-2 rounded-pill bg-success text-white"><tr><td class="px-3"><i class="fa fa-check-circle mr-2"></i>Present:(<?php if($getrowPrstnt!=0){ echo $getrowPrstnt; } ?>)</td></tr></table><table class="px-3 py-2 rounded-pill bg-danger text-white"><tr><td class="px-3"><i class="fa fa-check-circle mr-2"></i>Present:(<?php if($getrowPrstnt!=0){ echo $getrowPrstnta; } ?>)</td></tr></table></div></div>


			<?php
		}
			$getinfofch=mysqli_query($db,"SELECT * FROM $utable WHERE year='$yearr' and mysc='$mysc' and mysem='$mysem'");
			$getrowsfch=mysqli_num_rows($getinfofch);
			if($getrowsfch>0){
				echo '<input type="hidden" name="luctures" id="luctures" value="'.$lucture.'"><table class="table table-striped table-bordered"><thead><tr><th>SNo.</th><th>Name</th><th>Action</th><th>Status</th></tr></thead><tbody>';
				$counter=0;
				while($arrfch=mysqli_fetch_assoc($getinfofch))
					{ 
						$stid=$arrfch['id'];
						$sctionss=$arrfch['mysc'];
						$addyear=$arrfch['year'];
						$stsem=$arrfch['mysem'];
						
						$checkdate=mysqli_query($db,"SELECT * FROM $uadnctable WHERE  tid='".$_SESSION['login']."' and stid='$stid' and section='$sctionss' and addyear='$addyear' and sem='$stsem' and adncyr='$year' and adncmnt='$month' and adncday='$date'and lucture='$lucture'");
		$gerstus=mysqli_num_rows($checkdate);
		$getarrdnc=mysqli_fetch_assoc($checkdate);
						$counter=$counter+1; ?>
						<tr>
							<td><?php echo $counter; ?></td>
							<td><?php echo $arrfch['name']; ?></td>
							<td>
							
							
							<button class="followbtn px-2 rounded-pill following text-white" id="<?php echo $arrfch['id']; ?>">A</button>
							<button class="followbtnp px-2 rounded-pill unfollow text-white" id="<?php echo $arrfch['id']; ?>">P</button>
						</td>
						<td id="showst<?php echo $arrfch['id']; ?>"><?php if($gerstus!=0){ if($getarrdnc['status']!=""){ if($getarrdnc['status']=="P"){
								echo 'P <i class="fa fa-check-circle text-success ml-1"></i>';
								}else { echo 'A <i class="fa fa-close text-danger ml-1"></i>';}	
							}
						}
							?></td>
						</tr>

			<?php } echo'</tbody></table>'; 		
			}else {
				echo '<div class="badge badge-danger mt-3 py-2 w-100">No data found</div>';
			}
		}
 } } ?><script type="text/javascript">
$(document).ready(function(){	

$('button.followbtn').on('click', function(e){
e.preventDefault();
$button = $(this);
if($button.hasClass('following')){
var fid=$(this).attr('id');
var stus='A';
var luctures=$("#luctures").val();
$("#showst"+fid).html('<div class="spinner-border spinner-border-sm  text-success"></div>');
$.ajax({
url:"addattendence.php",
type:"POST",
data:"id="+fid+"&luctures="+luctures+"&stus="+stus,
success:function(msg)
{
	
if(msg==0){ $("#showst"+fid).html('A <i class="fa fa-close text-danger ml-1"></i>'); return false;}else{	

$("#showst"+fid).html('A <i class="fa fa-close text-danger ml-1"></i>');

}}});
}
});

$('button.followbtnp').on('click', function(e){
e.preventDefault();
$button = $(this);
if($button.hasClass('unfollow')){
var fidp=$(this).attr('id');
var stusp='P';
var lucturesp=$("#luctures").val();
$("#showst"+fidp).html('<div class="spinner-border spinner-border-sm  text-success"></div>');
$.ajax({
url:"addattendence.php",
type:"POST",
data:"id="+fidp+"&luctures="+lucturesp+"&stus="+stusp,
success:function(data)
{
	
if(data==0){ $("#showst"+fidp).html('P <i class="fa fa-check-circle text-success ml-1"></i>'); return false;}else{	

$("#showst"+fidp).html('P <i class="fa fa-check-circle text-success ml-1"></i>');

}}});
}
});

});
</script>