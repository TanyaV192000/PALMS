<?php 
 require 'db_connection.php';
if(isset($_SESSION['netssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['login']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

        if(isset($_POST['disrch']))
        {
           $disrch=trim(mysqli_escape_string($db,$_POST['disrch']));
           $lucture=trim(mysqli_escape_string($db,$_POST['lucture']));
           $mysc=trim(mysqli_escape_string($db,$_POST['mysc']));
           $mysem=trim(mysqli_escape_string($db,$_POST['mysem']));
           $byear=trim(mysqli_escape_string($db,$_POST['byear']));
           $year=trim(mysqli_escape_string($db,$_POST['year']));
           $mnthly=trim(mysqli_escape_string($db,$_POST['mnthly']));
           $getid=mysqli_query($db,"SELECT * FROM $utable WHERE logid='$disrch'");
           $getrowid=mysqli_num_rows($getid);
            if($getrowid>0)
            {
               
                $getidarry=mysqli_fetch_assoc($getid);
                $sid=$getidarry['id'];

                $maindata=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='$sid' AND section='$mysc' AND lucture='$lucture' AND adncyr='$year' AND adncmnt='$mnthly' AND sem='$mysem' AND addyear='$byear'");
                $mainrow=mysqli_num_rows($maindata);
                if($mainrow>0)
                {
                                    $counter=0;
                         $tpdata=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='$sid' AND section='$mysc' AND lucture='$lucture' AND adncyr='$year' AND adncmnt='$mnthly' AND sem='$mysem' AND addyear='$byear' and status='P'");
                $tprow=mysqli_num_rows($tpdata);
                $tadata=mysqli_query($db,"SELECT * FROM $uadnctable WHERE stid='$sid' AND section='$mysc' AND lucture='$lucture' AND adncyr='$year' AND adncmnt='$mnthly' AND sem='$mysem' AND addyear='$byear' and status='A'");
                $tarow=mysqli_num_rows($tadata);           
                   
                    echo '<div id="tblData"><table class="table table-bordered table-dark">
            <thead>
                <tr>
                    
                    <th>ID</th>
                    <th>Lucture</th>
                    <th>Section</th>
                    <th>Semester</th>
                    <th>Batch</th>
                    <th>Year</th>
                    <th>Month</th>
                </tr>
                <tr>
                    
                    <th class="bg-success">'.$disrch.'</th>
                    <th class="bg-success">'.$lucture.'</th>
                    <th class="bg-success">'.$mysc.'</th>
                    <th class="bg-success">'.$mysem.'</th>
                    <th class="bg-success">'.$byear.'</th>
                    <th class="bg-success">'.$year.'</th>
                    <th class="bg-success">'.$mnthly.'</th>
                </tr>
            </thead>'; echo '</table>'; ?>
                   <table  class="table table-bordered"><thead><tr><th><div class="badge rounded-pill badge-success w-100 py-2 text-center">Total Present:(<?php echo $tprow; ?>)</div></th><th><div class="badge rounded-pill badge-dark w-100 py-2 text-center">Total Absent: (<?php echo $tarow; ?>)   </div></th><th> <button class="btn btn-dark" onclick="exportTableToExcel('tblData')"> <i class="fa fa-print mr-2 text-success"></i> Export This</button></th></tr><tr><th>S.No.</th><th>Date</th><th>Status </th></tr></thead><tbody>
                   <?php
                    while($mainarr=mysqli_fetch_assoc($maindata))
                    { $counter=$counter+1; ?>
                        <tr>
                            <td><?php echo $counter; ?></td>
                            <td><?php echo $year; ?>-<?php echo $mnthly; ?>-<?php echo $mnthly; ?>-<?php echo $mainarr['adncday']; ?></td>
                            <td class=""><?php if($mainarr['status']=="P"){ echo '<span class="badge py-2 px-2 text-center badge-success">'; echo  $mainarr['status']; echo '</span>';}else { echo '<span class="badge py-2 px-2 text-center badge-danger">'; echo  $mainarr['status']; echo '</span>';} ?></td>
                        </tr>
                   <?php }
                }else { echo 'no data found';}
                echo '</tbody></table></div>';

            }
            
        }

    }
}
?>
<script>
    
        function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}</script>